package com.example.ghosthunter;

import java.util.ArrayList;

import android.graphics.Rect;
import android.location.Location;


public class Ghost {
	
	private double x;
	private double y; 
	private int dx;
	private int dy;
	private Rect hitbox;
	private double msGhost;
	private Human human;
	private Location loc;
	private final double WIDTH = 28;
	private final double HEIGHT = 26;
	
	public Ghost(Location loc) {
		loc = this.loc;
		this.x = (loc.getLatitude() + Math.random() * .0001);
		this.y = (loc.getLongitude() + Math.random() * .0001);
		hitbox = new Rect((int)x + 30, (int)y + 30, 50, 80);
		msGhost = 10; 
	}
	
	public Ghost(Location loc, Human h, int ms) {
		loc = this.loc;
		this.x = (loc.getLatitude() + Math.random() * .0001);
		this.y = (loc.getLongitude() + Math.random() * .0001);
		hitbox = new Rect((int)x + 30, (int)y + 30, 40, 40);
		msGhost = ms; 
		human = h;
	}
	
	public void moveGhost(float elapsedTime, ArrayList<Ghost> ghosts) {
		if(human.getX() > this.getX()) {
			x = (x+msGhost*elapsedTime);
			hitbox.set((int)(x - .5 * WIDTH), (int)(y + .5 * HEIGHT), (int)(x + .5 * WIDTH), (int)(y - .5 * HEIGHT));
		} else if(human.getX() < this.getX()) {
			x = (x-msGhost*elapsedTime);
			hitbox.set((int)(x - .5 * WIDTH), (int)(y + .5 * HEIGHT), (int)(x + .5 * WIDTH), (int)(y - .5 * HEIGHT));
		}
	
		if(human.getY() > this.getY()) {
			y = (y+msGhost*elapsedTime);
			hitbox.set((int)(x - .5 * WIDTH), (int)(y + .5 * HEIGHT), (int)(x + .5 * WIDTH), (int)(y - .5 * HEIGHT));			
		} else if(human.getY() < this.getY()) {
			y = (y-msGhost*elapsedTime);	
			hitbox.set((int)(x - .5 * WIDTH), (int)(y + .5 * HEIGHT), (int)(x + .5 * WIDTH), (int)(y - .5 * HEIGHT));			
		}

}

	public boolean hitsGhost(Ghost g) {
		return this.hitbox.intersect(g.getHitbox());
	}

	public int getDx() {
		return dx;
	}

	public void setDx(int dx) {
		this.dx = dx;
	}

	public int getDy() {
		return dy;
	}

	public void setDy(int dy) {
		this.dy = dy;
	}

	public double getMsGhost() {
		return msGhost;
	}

	public void setMsGhost(int msGhost) {
		this.msGhost = msGhost;
	}

	public Human getHuman() {
		return human;
	}

	public void setHuman(Human human) {
		this.human = human;
	}

	public double getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public double getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public Rect getHitbox() {
		return hitbox;
	}

	public void setHitbox(Rect hitbox) {
		this.hitbox = hitbox;
	}


}